
class Player
  def initialize(name)
    @name = name
    @hp = 10
  end
  def take_damage(dmg)
    @hp -= dmg
    puts "#{@name} took #{dmg} damage, they have #{@hp} hp left."
  end
end

class Monster
  def initialize(type, hp)
    @type = type
    @hp = hp
  end
  def take_damage(dmg)
    @hp -= dmg
    if @hp <= 0
      puts "the #{@type} died."
    else
      puts "The #{@type} took #{dmg} damage, and has #{@hp} left"
    end
  end
end

mark = Player.new('mark')
slooga = Player.new('slooga')
orc = Monster.new('orc', 10)
troll = Monster.new('troll', 30)

mark.take_damage(3)
troll.take_damage(10)
orc.take_damage(10)

