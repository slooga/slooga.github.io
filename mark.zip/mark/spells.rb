$castdata = ['data']

$casts = ['data']

def handle_cast(args)
    spell = args.first
    if $casts.include?(spell)
        puts "casting #{spell}"
    else
        puts "I don't know the spell #{spell}"
    end
end     

