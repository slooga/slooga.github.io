$props = ['some trees sway', 'a spider crawls over your face', 'a squirrel jumps over your head', 'purple bushes swish around the area']
def loot_randomize()
  $zloot.shuffle.first
end

class Room
  attr_reader :name, :desc, :exits, :hidden_exits
  attr_accessor :items, :hidden_items, :enemies
  def initialize(name, properties)
    @name = name
    @desc = properties[:desc]                                                                              
    @exits = properties[:exits]
    @items = properties[:items] || []
    @hidden_items = properties[:hidden_items] || []
    @hidden_exits = properties[:hidden_exits] || []
    @enemies = properties[:enemies] || []
    MAP[@name] = self
  end

  def get_room_description
    result = []
    result << @name.to_s
    if @desc.is_a?(String)
      result << @desc
    else
      result += @desc
    end
    if @exits.size == 0
      result << "there are no exits, you're stuck!"
    else
      result << "possible exits: " + @exits.keys.join(', ')
    end
    if @items.size > 0
      result << "there are some items in the room: " + @items.join(", ")
    end
    if @enemies.size > 0
      result << "there are some enemies here! " + @enemies.join(', ')
    end
    return result.join("\n")
  end

  def has_item?(item)
    return @items.include?(item)
  end

  # returns either []
  # or ['some item']

$random_item = ['hammer', 'horn', 'meat','arrow','matches','gemstone','bow','spear']
  def get_random_hidden_item
    if rand(100) < CHANCE_FOR_RANDOM_ITEM  
      return [$random_item.shuffle.first]
    end
    
    return []
  end

  def get_random_exits(entered_from_dir)
    # this ensures we can go back to wherever we came from
    result = {
      REVERSE_DIRECTIONS[entered_from_dir] => @name,
    }
    rand(4).times do 
      new_exit_direction = nil
      begin
        new_exit_direction = ALL_DIRECTIONS.shuffle.first
      end while result[new_exit_direction]
      result[new_exit_direction] = :random
    end
    # generate some other random exits here
    return result
  end
  
  def generate_random_room(entered_from_dir)
      new_name = SecureRandom.uuid
      random_desc = $props.shuffle.first
      properties = {
        :desc => random_desc,
        :exits => get_random_exits(entered_from_dir),
        :hidden_items => get_random_hidden_item,
      }
      Room.new(new_name, properties)
      @exits[entered_from_dir] = new_name
      return new_name
  end
end