def get_lev_loot
    
end
$levels = 1
get_lev_loot
$level_loot1 = ['rope', 'knife']
$level_loot2 = ['weard', 'pickaxe']
$level_loot3 = ['gem']
$level_loot4 = ['sword']
$level_loot5 = ['bos tiket']
