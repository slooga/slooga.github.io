def handle_command(cmd, args)
  room = MAP[$location]
  arg = args.to_a.first
  if cmd == 'quit'
    puts 'changes will not be saved are you sure you want to quit yes or no'
    if gets.strip == 'yes'
      exit 0
    end  
  elsif cmd == 'look'
    puts room.get_room_description
  elsif cmd == 'help'
    display_help
  elsif room.exits.include?(cmd)
    $location = room.exits[cmd]
    if $location == :random
      $location = room.generate_random_room(cmd)
    end
    room = MAP[$location]
    puts room.get_room_description
  elsif DIRECTIONS.include?(cmd)
    puts "I can't go that way."
  elsif ['db', 'backpack', 'inventory', 'b'].include?(cmd)
    puts 'backpack: ' + $backpack.join(', ')
  elsif cmd == 'take'
    if room.has_item?(arg)
      $backpack << arg
      room.items.delete(arg)
      puts "you take the: " + arg  
    else  
      puts "there is no '#{args.join(' ')}' here."
    end
  elsif cmd == 'read'
    if $backpack.include?(arg)
      puts $objects[arg]['text'].join("\n")
    else  
      puts "you're not holding a #{arg}"
    end  
  elsif cmd == 'search'
    if room.hidden_items.size > 0
      puts "you found: " + room.hidden_items.join(", ") 
      room.items += room.hidden_items
      room.hidden_items = []
    else
      puts "you didn't find anything."
    end

  elsif cmd == 'select'
    puts 'backpack contains' + $backpack.to_s 
    if $backpack.include?(arg)
      $selected = arg
      puts "you have selected " + arg
    end
  elsif  cmd == 'attack'
    if room.enemies.to_a.include?(arg)
      $attacking = arg
      puts "you attacked " + arg
   if arg == 'zapper'
    $zhealth = $zhealth - 1

    elsif arg.to_s != ''
      puts "there is no #{arg} here!"
    else
      puts "there are no enemies here!"
    end
  elsif  cmd == 'options'
    puts "commands can do back, teach"
    cmd, args = get_command
    if cmd == 'back'
      puts 'back to game'
    end
  elsif $zhealth == 0
    room.enemies.delete('zapper')    
    end  
    $mapped_commands[args[0]] = args[2]
  elsif cmd == 'drop'
    if $backpack.include?(arg)
      room.items << arg
      $backpack.delete(arg)
      puts "you drop the: " + arg  
    else  
      puts "you do not have '#{args.join(' ')}' in your backpack."     
    end
  elsif cmd == 'cast'
    handle_cast(args)
  elsif cmd == 'r'
    "you're are lost in a forest, the trees sway and bushes blow in the wind"        
  else
    return false
  end
  return true
end
def cmd_loop
    while true do
      cmd, args = get_command
      next if !cmd
      if !handle_command(cmd, args)
          puts "I don't know what : " + cmd + " means"
      end
    end
end