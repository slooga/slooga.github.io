MAP = {}

Room.new(:forest, {
        :desc => "you're are lost in a forest, the trees sway and bushes blow in the wind",
        :exits => {
            'east' => :forest_east,
            'west' => :forest_west,
            'north' => :forest_north,
            'south' => :random,
         }
    })

Room.new(:caveeast, {
      :desc =>"it gets dark spider creep across your face!",
      :items => ['staff'],
      :hidden_items => ['hammer'],
      :enemies => ['zap'],
      :exits => {
       'west' => :cave
      }
    })

Room.new(:cave, {
      :desc =>"the gemstone swirls around & flys into your hands (woosh)",
      :items => ['gemstone'],
      :hidden_items => ['hammer'],
      :enemies => ['zapper'],
      :exits => {
       'west' => :forest_northnorthnorthnorth,
       'east' => :caveeast,
      }
    })

Room.new(:forest_northnorthnorthnorth, {
      :desc => "a green gemstone glows in a cave to enter cave go east",
      :exits => {
        'south' => :forest_northnorthnorth,
        'east' => :cave,
      }
    })

Room.new(:forest_northnorthnorth, {
      :desc => "you run right past the horse.  There is a green and brown tree swaying with a book in it.",
      :items => ['book'],
      :exits => {
        'south' => :forest_northnorth,
        'north' => :forest_northnorthnorthnorth,
      }
    })
  
Room.new(:forest_northnorth, {
      :desc => "you run right into the horse slam! you're hurt",
      :exits => {
        'south' => :forest_north,
        'north' => :forest_northnorthnorth,
        'east' => :random,
      }
    })

Room.new(:forest_north, {
        :desc => 'you see a horse in the distance with yellow eyes green trees sway',
        :exits =>   {
            'east' =>  :forest_east,
            'west' =>  :forest_west,
            'north' => :forest_northnorth,
            'south' => :forest,
          }
    })

Room.new(:forest_east, {
        :desc => ['the forest grows dark and shadows show in the',
                  'dim light'],
        :exits => {
            'west' => :forest,
            'east' => :random,
        }
    })

Room.new(:forest_west, {
        :desc => [
             "you shiver a tornado is heading right torwards you from the west",
             "run!",
             "a person picks you up and puts you in a bag",
             "you struggle in the bag",
             "you wake on the forest floor",
        ],
        :exits => {
            'east' => :forest,
            'west' => :tornado,
        }
    })

Room.new(:tornado, {
        :desc => 'you are dead, you ran into the tornado',
        :exits => {}
    })