#!/usr/bin/env ruby
require 'securerandom'
require_relative 'room'
require_relative 'map'
require_relative 'mobs'
require_relative 'commands'
require_relative 'spells'
require_relative 'levels'

REVERSE_DIRECTIONS = {
  'north' => 'south',
  'south' => 'north',
  'east' => 'west',
  'west' => 'east',
}
ALL_DIRECTIONS = REVERSE_DIRECTIONS.keys
CHANCE_FOR_RANDOM_ITEM = 10


$zhealth = 2
$selected_item = nil
$inventory = []

$objects = {
  'book' => {
    'text' => [
      'this is line 1',
      'this is line 2'
    ]
  }
}

$mapped_commands = {
  '^' => 'north',
  'v' => 'south',
  '>' => 'east',
  '<' => 'west',
  'n' => 'north',
  's' => 'south',
  'e' => 'east',
  'w' => 'west',
  'm' => 'map',
  'o' => 'options'
}

DIRECTIONS = ['north', 'south', 'east', 'west'].freeze

def get_command
  words = gets.strip.downcase.split(' ')
  cmd = words.first
  args = words[1..-1]
  if $mapped_commands[cmd]
    cmd = $mapped_commands[cmd]
  end
  return cmd, args
end

def display_help
  puts "north = ^"
  puts "south = v"
  puts "east  = >"
  puts "west  = <"
  puts "look shows you the area you're in again"
  puts "quit exits the game"
  puts "help displays this list of commands"
  puts "m = map_display" 
  puts "db = display backpack"
  puts "o = options" 
end

def current_room
  return MAP[$location]
end

def look_at_room(room_name)
  $location = room_name
  puts MAP[$location].get_room_description
end


$backpack = ["knife", "torch"]
puts 'welcome to mark text adventure!'
display_help
Zombie.new
$location = :forest
puts MAP[$location].get_room_description
cmd_loop

#stop here  
