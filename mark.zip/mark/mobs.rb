
# if a mobs aggro level > 5 then it will attack you
# damage is the range of damage the mob can do
# accuracy represents the chance for this mob to hit a character of the same level
# level affects the Mobs chance to hit / be hit by a character
class Mob
    attr_accessor :health
    attr_reader :arrival_text, :description, :aggro
    def initialize
        @aggro = 1
        @health = 10
        @damage = (1..3)
        @accuracy = 50
        @level = 1
    end
    # returns the amount of damage done by one attack from this mob
    def get_damage(char_level)
        base_damage = @damage.to_a.shuffle.first
        if @level > char_level
            base_damage += rand(@level - char_level)
        else
            base_damage -= rand(char_level - @level)
        end
        return base_damage
    end

    # returns true if this attack from the mob will hit a character of
    # the given char_level
    def does_attack_hit?(char_level)
        chance = @accuracy + @level * 10 - char_level * 10
        if rand(100) < chance
            return true
        else
            return false
        end
    end
end

class Zombie < Mob
  def initialize
    @arrival_text = 'urug urrrrrragarrru urrr'
    @description = "It's a zombie.  Pieces of rotting flesh hang from it's face and arms."
    @aggro = 10
  end
end
class Horse < Mob
    def initialize
        @arrival_text = 'you see a horse, crunch crunch.'
        @description = "It's a large brown horse with a plaited mane."
    end
end
class Ogre < Mob
    def initialize
        @arrival_text = 'smack smack an ogre smacks his hands at you'
        @description = "It's a huge beast of an ogre, with a massive spiked club in his hand and an angry look in his eye."
        @health = 30
        @aggro = 4
        @damage = (4..10)
    end  
end
class Phantom  < Mob
    def initialize
        @arrival_text = 'whack, you whack your head on a phantom'
        @description = "The phantom floats eerily in the air, the ground visible beyond its legs."
        @health = 15
        @aggro = 5
        @damage = (2..5)
    end  
end